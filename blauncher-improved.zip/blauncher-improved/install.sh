#!/usr/bin/env bash
# blauncher installer
# This script adds blauncher to your ~/.bashrc

set -e

BASHRC="$HOME/.bashrc"
BLAUNCHER_URL="https://raw.githubusercontent.com/mcqueentrading/blauncher/main/blauncher.sh"
TEMP_FILE="/tmp/blauncher.sh"

echo "==============================================="
echo "  blauncher installer"
echo "==============================================="
echo ""

# Check if bashrc exists
if [ ! -f "$BASHRC" ]; then
    echo "Error: ~/.bashrc not found"
    echo "Creating ~/.bashrc..."
    touch "$BASHRC"
fi

# Check if already installed
if grep -q "blauncher" "$BASHRC"; then
    echo "⚠️  blauncher appears to already be installed in ~/.bashrc"
    echo ""
    read -p "Do you want to reinstall? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Installation cancelled."
        exit 0
    fi
    
    # Remove old installation
    echo "Removing old installation..."
    sed -i '/# blauncher/,/complete.*_orphan_complete/d' "$BASHRC"
fi

# Download or use local file
if [ -f "blauncher.sh" ]; then
    echo "✓ Using local blauncher.sh"
    cp blauncher.sh "$TEMP_FILE"
else
    echo "📥 Downloading blauncher.sh..."
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL "$BLAUNCHER_URL" -o "$TEMP_FILE"
    elif command -v wget >/dev/null 2>&1; then
        wget -q "$BLAUNCHER_URL" -O "$TEMP_FILE"
    else
        echo "Error: Neither curl nor wget found. Please install one of them."
        exit 1
    fi
fi

# Append to bashrc
echo ""
echo "📝 Adding blauncher to ~/.bashrc..."
echo "" >> "$BASHRC"
cat "$TEMP_FILE" >> "$BASHRC"
echo "" >> "$BASHRC"

# Cleanup
rm -f "$TEMP_FILE"

echo ""
echo "✅ Installation complete!"
echo ""
echo "To start using blauncher, run:"
echo "  source ~/.bashrc"
echo ""
echo "Or open a new terminal."
echo ""
echo "Usage examples:"
echo "  oo firefox                    # Launch Firefox and exit shell"
echo "  op nemo ~/Downloads           # Open file manager, keep shell"
echo "  orp chromium                  # Launch with maximum resilience"
echo ""
echo "For more information, visit:"
echo "  https://github.com/mcqueentrading/blauncher"
echo ""
