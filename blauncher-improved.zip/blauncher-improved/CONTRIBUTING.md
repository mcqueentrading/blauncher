# Contributing to blauncher

Thank you for considering contributing to blauncher! This document provides guidelines for contributing.

## How to Contribute

### Reporting Bugs

If you find a bug, please open an issue with:

1. **Clear title** describing the problem
2. **Steps to reproduce** the issue
3. **Expected behavior** vs **actual behavior**
4. **Environment details:**
   - Bash version (`bash --version`)
   - OS and distribution
   - Terminal emulator

Example:
```
Title: Tab completion adds space after directory

When I type `oo nemo ~/.local` and press tab, it adds a space instead 
of showing directory contents.

Expected: Show contents of ~/.local/
Actual: Adds a space after ~/.local

Environment:
- Bash 5.1.16
- Arch Linux
- Kitty terminal
```

### Suggesting Features

Feature requests are welcome! Please:

1. Check existing issues to avoid duplicates
2. Explain **what** you want and **why** it's useful
3. Provide use cases or examples

### Pull Requests

1. **Fork** the repository
2. **Create a branch** for your feature:
   ```bash
   git checkout -b feature/my-awesome-feature
   ```

3. **Make your changes:**
   - Follow existing code style
   - Add comments for complex logic
   - Test thoroughly

4. **Commit** with clear messages:
   ```bash
   git commit -m "Add timeout to oo() function"
   ```

5. **Push** to your fork:
   ```bash
   git push origin feature/my-awesome-feature
   ```

6. **Open a Pull Request** with:
   - Description of changes
   - Why this change is needed
   - How you tested it

## Code Style

### Bash Best Practices

- Use `#!/usr/bin/env bash` shebang
- Quote variables: `"$var"` not `$var`
- Use `[[` instead of `[` for conditionals
- Check command existence: `command -v cmd >/dev/null`
- Use meaningful variable names

### Comments

- Add comments for non-obvious logic
- Explain *why*, not *what* (code shows what)
- Use section headers for organization:
  ```bash
  #######################
  # SECTION NAME
  #######################
  ```

### Function Documentation

Document functions with:
```bash
# function_name - Brief description
# Detailed explanation of what it does.
# Include any gotchas or important notes.
function_name() {
    # implementation
}
```

## Testing

Before submitting:

1. **Test in a clean environment:**
   ```bash
   bash --noprofile --norc
   source blauncher.sh
   ```

2. **Test all three functions:**
   - `oo command` - Should exit shell
   - `op command` - Should print PID
   - `orp command` - Should work with nohup

3. **Test tab completion:**
   - Command name completion
   - File path completion
   - Directory completion with trailing slash

4. **Test edge cases:**
   - Commands with arguments
   - Paths with spaces
   - Non-existent commands
   - Quick-exiting programs

## Compatibility

blauncher should work on:

- ✅ Bash 4.0+
- ✅ Linux (all major distributions)
- ✅ macOS (with bash installed)
- ⚠️ WSL (not officially tested, but should work)

If you're adding features, ensure they work across these platforms.

## Documentation

Update documentation for:

- **New features** → Add to README.md
- **Bug fixes** → Update troubleshooting section
- **Breaking changes** → Clearly mark in PR description

## Questions?

Feel free to:
- Open an issue for questions
- Start a discussion for larger ideas
- Reach out to [@mcqueentrading](https://github.com/mcqueentrading)

## Code of Conduct

Be respectful, constructive, and welcoming. This is a small project, but we value kindness and collaboration.

---

Thank you for contributing! 🎉
