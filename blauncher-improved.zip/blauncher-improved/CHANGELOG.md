# Changelog

All notable changes to blauncher will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Comprehensive README with examples and troubleshooting
- Installation script (`install.sh`)
- Contributing guidelines
- Changelog
- Timeout mechanism in `oo()` to prevent infinite hangs
- Better code comments and documentation

### Fixed
- Tab completion now properly handles directories
- Directory paths no longer get automatic spaces after completion
- File path arguments now work correctly with GUI applications
- Tab completion shows directory contents instead of adding space

### Changed
- Improved `_orphan_complete` function for smarter tab completion
- Added `-o nospace` flag to `complete` command
- Reorganized code structure with clear sections
- Updated function descriptions and comments

## [1.0.0] - Initial Release

### Added
- `oo` function - Launch and exit shell
- `op` function - Launch and keep shell running with PID
- `orp` function - Launch with nohup for maximum resilience
- Basic tab completion for commands and files
- GPL-3.0 license

---

[Unreleased]: https://github.com/mcqueentrading/blauncher/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/mcqueentrading/blauncher/releases/tag/v1.0.0
