#!/usr/bin/env bash
# blauncher test suite
# Tests basic functionality of oo, op, and orp functions

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

TESTS_PASSED=0
TESTS_FAILED=0

# Load blauncher
if [ ! -f "blauncher.sh" ]; then
    echo -e "${RED}Error: blauncher.sh not found${NC}"
    exit 1
fi

source blauncher.sh

echo "========================================"
echo "  blauncher Test Suite"
echo "========================================"
echo ""

# Test helper functions
pass() {
    echo -e "${GREEN}✓${NC} $1"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

fail() {
    echo -e "${RED}✗${NC} $1"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

warn() {
    echo -e "${YELLOW}⚠${NC} $1"
}

# Test 1: Check if functions are defined
echo "Testing function definitions..."
if type oo >/dev/null 2>&1; then
    pass "oo() function is defined"
else
    fail "oo() function is not defined"
fi

if type op >/dev/null 2>&1; then
    pass "op() function is defined"
else
    fail "op() function is not defined"
fi

if type orp >/dev/null 2>&1; then
    pass "orp() function is defined"
else
    fail "orp() function is not defined"
fi

if type _orphan_complete >/dev/null 2>&1; then
    pass "_orphan_complete() function is defined"
else
    fail "_orphan_complete() function is not defined"
fi

echo ""

# Test 2: Check if completion is registered
echo "Testing tab completion setup..."
if complete -p oo >/dev/null 2>&1; then
    pass "oo completion is registered"
else
    fail "oo completion is not registered"
fi

if complete -p op >/dev/null 2>&1; then
    pass "op completion is registered"
else
    fail "op completion is not registered"
fi

if complete -p orp >/dev/null 2>&1; then
    pass "orp completion is registered"
else
    fail "orp completion is not registered"
fi

echo ""

# Test 3: Test op function (doesn't exit shell)
echo "Testing op function..."
if command -v sleep >/dev/null 2>&1; then
    output=$(op sleep 1 2>&1)
    
    if [[ "$output" =~ "orphan, no child" ]]; then
        pass "op outputs expected message"
    else
        fail "op does not output expected message"
    fi
    
    if [[ "$output" =~ \([0-9]+\) ]]; then
        pid=$(echo "$output" | grep -oP '\(\K[0-9]+(?=\))')
        pass "op outputs PID: $pid"
        
        # Check if process started
        sleep 0.5
        if kill -0 "$pid" 2>/dev/null; then
            pass "Process $pid is running"
            kill "$pid" 2>/dev/null || true
        else
            warn "Process $pid already exited (this is normal for quick processes)"
        fi
    else
        fail "op does not output PID"
    fi
else
    warn "sleep command not available, skipping op test"
fi

echo ""

# Test 4: Test orp function
echo "Testing orp function..."
if command -v sleep >/dev/null 2>&1; then
    # Create a subshell to prevent script exit
    (
        output=$(orp sleep 2 2>&1)
        
        if [[ "$output" =~ "orphan, no child" ]]; then
            pass "orp outputs expected message"
        else
            fail "orp does not output expected message"
        fi
    )
    
    # Clean up any lingering sleep processes
    pkill -f "sleep 2" 2>/dev/null || true
else
    warn "sleep command not available, skipping orp test"
fi

echo ""

# Test 5: Test completion function
echo "Testing _orphan_complete function..."

# Mock completion context
COMP_WORDS=("oo" "sle")
COMP_CWORD=1
COMPREPLY=()

_orphan_complete

if [ ${#COMPREPLY[@]} -gt 0 ]; then
    pass "Completion generates suggestions for command names"
    echo "   Example suggestions: ${COMPREPLY[@]:0:3}"
else
    fail "Completion does not generate suggestions for command names"
fi

# Test file completion
COMP_WORDS=("op" "/et")
COMP_CWORD=1
COMPREPLY=()

_orphan_complete

if [ ${#COMPREPLY[@]} -gt 0 ]; then
    pass "Completion generates suggestions for file paths"
else
    fail "Completion does not generate suggestions for file paths"
fi

echo ""

# Test 6: Test with non-existent command
echo "Testing error handling..."
output=$(op nonexistentcommand123 2>&1 || true)
if [[ "$output" == *"orphan, no child"* ]] || [[ "$output" == "" ]]; then
    pass "Handles non-existent commands gracefully"
else
    warn "Unexpected output for non-existent command: $output"
fi

echo ""

# Summary
echo "========================================"
echo "  Test Results"
echo "========================================"
echo -e "${GREEN}Passed: $TESTS_PASSED${NC}"
echo -e "${RED}Failed: $TESTS_FAILED${NC}"
echo ""

if [ $TESTS_FAILED -eq 0 ]; then
    echo -e "${GREEN}All tests passed!${NC}"
    exit 0
else
    echo -e "${RED}Some tests failed.${NC}"
    exit 1
fi
